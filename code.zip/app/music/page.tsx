"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import Image from "next/image"
import { Music, Play } from "lucide-react"
import { AspectRatio } from "@/components/ui/aspect-ratio"

export default function MusicPage() {
  const songs = [
    {
      title: "Rising Star",
      genre: "Pop",
      releaseDate: "2024",
      description: "An uplifting anthem about pursuing dreams and never giving up",
      image: "/music-album-cover-pop.jpg",
    },
    {
      title: "Heartbeat",
      genre: "R&B",
      releaseDate: "2024",
      description: "A smooth R&B track with soulful vocals and contemporary production",
      image: "/music-album-cover-rnb.jpg",
    },
    {
      title: "Neon Nights",
      genre: "Pop",
      releaseDate: "2023",
      description: "An energetic pop song perfect for any celebration or event",
      image: "/music-album-cover-neon.jpg",
    },
    {
      title: "Echoes",
      genre: "Soul",
      releaseDate: "2023",
      description: "A powerful ballad showcasing vocal range and emotional depth",
      image: "/music-album-cover-soul.jpg",
    },
    {
      title: "Dance With Me",
      genre: "Pop",
      releaseDate: "2023",
      description: "An upbeat track perfect for weddings and celebrations",
      image: "/music-album-cover-dance.jpg",
    },
    {
      title: "Midnight Dreams",
      genre: "R&B",
      releaseDate: "2022",
      description: "A dreamy R&B track with lush production and silky vocals",
      image: "/music-album-cover-dreamy.jpg",
    },
  ]

  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero */}
      <section className="pt-32 pb-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-primary/10 to-background">
        <div className="max-w-4xl mx-auto text-center space-y-4">
          <h1 className="text-5xl font-bold">My Music</h1>
          <p className="text-xl text-muted-foreground">Explore my songs and performances</p>
        </div>
      </section>

      {/* Music Grid */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {songs.map((song) => (
              <div key={song.title} className="group cursor-pointer">
                <AspectRatio ratio={1} className="mb-4 rounded-lg overflow-hidden shadow-lg">
                  <Image
                    src={song.image || "/placeholder.svg"}
                    alt={song.title}
                    fill
                    className="object-contain group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <button className="bg-primary text-primary-foreground p-4 rounded-full hover:bg-primary/90 transition-colors">
                      <Play size={32} />
                    </button>
                  </div>
                </AspectRatio>
                <h3 className="text-xl font-bold">{song.title}</h3>
                <div className="flex items-center gap-2 mb-2">
                  <Music size={16} className="text-primary" />
                  <p className="text-primary font-semibold text-sm">{song.genre}</p>
                </div>
                <p className="text-sm text-muted-foreground mb-2">Released {song.releaseDate}</p>
                <p className="text-muted-foreground text-sm">{song.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-4xl font-bold">Want me to perform your favorite song?</h2>
          <p className="text-lg text-muted-foreground">
            Request a custom setlist or let me know your favorite tracks when you book me for your event.
          </p>
          <a
            href="/booking"
            className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:bg-primary/90 transition-colors"
          >
            Book a Performance
          </a>
        </div>
      </section>

      <Footer />
    </div>
  )
}
